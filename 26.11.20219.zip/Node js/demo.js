var http = require('http');
var dt = require('./date');
http.createServer(function(req, res)
{
	res.writeHead(200, {'Content-Type' : 'text/html'});
	res.write('Date and time is : ' + dt.myDateTime());
	res.end('Date and time is : ' + req.url );
}).listen(8080);