var url = require('url');
var address = 'https://www.w3schools.com/nodejs/nodejs_url.asp';
var parse = url.parse(address, true);

console.log(parse.host);
console.log(parse.pathname);
console.log(parse.search);

var qd = parse.query;
console.log(qd.month);
