package test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

class TestFileHandler {

	@Test
	void test() throws SecurityException, IOException {
		assertNotNull(JunitTestDicomVR.getFileHandler());
	}

}
