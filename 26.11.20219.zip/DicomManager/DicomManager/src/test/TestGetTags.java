package test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;

import org.dcm4che3.data.Attributes;
import org.junit.jupiter.api.Test;

class TestGetTags {

	@Test
	void test() throws Exception {
		JunitTestDicomVR testDicomVR = new JunitTestDicomVR();
		testDicomVR.parseDCMFile(new File("C:\\Users\\1026837\\Desktop\\dicom 2\\0003.DCM"));
		Attributes tags = testDicomVR.getTags();
		assertNotNull(tags);
	}

}
 