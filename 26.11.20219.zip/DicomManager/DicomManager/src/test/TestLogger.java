package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.logging.Logger;

import org.junit.jupiter.api.Test;

import controller.DicomVRController;

class TestLogger {

	@Test
	void test() {
		JunitTestDicomVR logger = new JunitTestDicomVR();
		Logger l = logger.getLogger();
		assertEquals(Logger.getLogger(DicomVRController.class.getName()), l);
		
	}

}
