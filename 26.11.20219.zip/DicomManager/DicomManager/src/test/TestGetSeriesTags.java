package test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class TestGetSeriesTags {

	@Test
	void test() throws Exception {
		JunitTestDicomVR testDicomVR = new JunitTestDicomVR();
		testDicomVR.parseDCMFile(new File("C:\\Users\\1026837\\Desktop\\dicom 2\\0003.DCM"));
		ArrayList<String> series =  testDicomVR.getSeriesTags();
		assertNotNull(series);
	}

}
