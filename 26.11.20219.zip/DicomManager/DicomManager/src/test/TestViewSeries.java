package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import model.Series;

class TestViewSeries {

	@Test
	void test() throws Exception {
		JunitTestDicomVR series = new JunitTestDicomVR();
		ArrayList<Series> serieslist = series.viewAllSeries("1.3.12.2.1107.5.4.3.123456789012345.19950922.121803.6");
		assertEquals("1.3.12.2.1107.5.4.3.123456789012345.19950922.121803.8", serieslist.get(0).getSeriesId());
	}

}
