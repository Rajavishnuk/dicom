package test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;

import org.junit.jupiter.api.Test;

class TestCreateObj {

	@Test
	void test() throws Exception {
		JunitTestDicomVR create = new JunitTestDicomVR();
		create.parseDCMFile(new File("C:\\Users\\1026837\\Desktop\\dicom 2\\0003.DCM"));
		
		assertNotNull(create.createDCMObj());
	}

}
