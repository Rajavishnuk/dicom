package test;

import java.io.File;

import org.junit.jupiter.api.Test;

import controller.DicomVRController;

class TestInsertPatient {

	@Test
	void test() throws Exception {
		JunitTestDicomVR insert = new JunitTestDicomVR();
		insert.parseDCMFile(new File("C:\\Users\\1026837\\Downloads\\dicom_viewer_Mrbrain\\MRBRAIN.DCM"));			
		DicomVRController controller = 	insert.createDCMObj();
		model.PatientStudy p = controller.getPatient();
		insert.insertPatient(p);
	}

}
