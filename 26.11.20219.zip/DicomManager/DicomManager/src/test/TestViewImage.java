package test;

import static org.junit.jupiter.api.Assertions.*;


import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class TestViewImage {

	@Test
	void test() throws Exception {
		JunitTestDicomVR image = new JunitTestDicomVR();
		ArrayList<model.Image> i = image.viewAllImage("1.3.12.2.1107.5.4.3.123456789012345.19950922.121803.6", "1.3.12.2.1107.5.4.3.123456789012345.19950922.121803.8") ;
		assertEquals("1.3.12.2.1107.5.4.3.321890.19960124.162922.29", i.get(0).getImageNumber());
	}

}
