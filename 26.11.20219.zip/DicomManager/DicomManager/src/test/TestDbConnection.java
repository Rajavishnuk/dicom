package test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

class TestDbConnection {

	@Test
	void test() throws ClassNotFoundException, SQLException {
		JunitTestDicomVR dbcon = new JunitTestDicomVR();
		assertNotNull(dbcon.getCon());
	}

}
