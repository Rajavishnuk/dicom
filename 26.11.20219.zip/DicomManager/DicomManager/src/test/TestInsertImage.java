package test;


import java.io.File;

import org.junit.jupiter.api.Test;

import controller.DicomVRController;

class TestInsertImage {

	@Test
	void test() throws Exception {
		JunitTestDicomVR insert = new JunitTestDicomVR();
		insert.parseDCMFile(new File("C:\\Users\\1026837\\Downloads\\dicom_viewer_Mrbrain\\MRBRAIN.DCM"));			
		DicomVRController controller = 	insert.createDCMObj();
		model.Image i = controller.getImage();
		insert.insertImage(i);
	}

}
