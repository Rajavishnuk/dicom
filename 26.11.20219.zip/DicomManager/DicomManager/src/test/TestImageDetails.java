package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.LinkedHashMap;

import org.junit.jupiter.api.Test;

class TestImageDetails {

	@Test
	void test() throws Exception {
		JunitTestDicomVR imageDetails = new JunitTestDicomVR();
		LinkedHashMap<String, String> details = imageDetails.details("1.3.12.2.1107.5.4.3.123456789012345.19950922.121803.6", "1.3.12.2.1107.5.4.3.123456789012345.19950922.121803.8", "1.3.12.2.1107.5.4.3.321890.19960124.162922.29");
		assertNotNull(details);
	}

}
