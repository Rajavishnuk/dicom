package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestDBConnectorInstance {

	@Test
	void test() {
		JunitTestDicomVR db = new JunitTestDicomVR();
		assertNotNull(db.getDbInstance());
	}

}
