package test;


import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.dcm4che3.data.Attributes;
import controller.DicomVRController;
import dao.DbConnector;
import dao.ImageDAO;
import dao.PatientStudyDAO;
import dao.SeriesDAO;
import logger.LoggerFormat;
import model.DCMObjFactory;
import model.DCMParser;
import model.PatientStudy;
import model.Series;

public class JunitTestDicomVR {
	DCMParser dcmParser = new DCMParser();
	public void parseDCMFile(File f) throws Exception
	{
		dcmParser.dcmFileParser(f);		
	}
	
	public  Attributes getTags() {
		return DCMParser.getTags();
	}
	
	public ArrayList<String> getPatientStudyTags()
	{
		return dcmParser.getPatientStudyList();
	}
	
	public ArrayList<String> getSeriesTags()
	{
		return dcmParser.getSeriesList();
	}
	
	public ArrayList<String> getImageTags()
	{
		return dcmParser.getImageList();
	}
	
	public Logger getLogger()
	{
		Logger logger =  Logger.getLogger(DicomVRController.class.getName());
		logger.setLevel(Level.FINE);
		return logger;
	}
	
	public DbConnector getDbInstance()
	{
		return DbConnector.getInstance();
	}
	
	public Connection getCon() throws ClassNotFoundException, SQLException
	{
		return DbConnector.getInstance().getConnection();
	}
	
	public DicomVRController createDCMObj() throws SecurityException, IOException
	{
		new DicomVRController(new DCMParser());
		return DCMObjFactory.createDCMObj();
	}
	
	public static FileHandler getFileHandler() throws SecurityException, IOException
	{
		return LoggerFormat.getFileHandler();
	}
	
	public ArrayList<PatientStudy> viewAllPatient() throws Exception
	{
		return DicomVRController.viewAllPatientStudy();
	}
	
	public ArrayList<model.Image> viewAllImage(String studyid, String seriesid) throws Exception 	{
		return DicomVRController.viewImage(studyid, seriesid);
	}
	
	public ArrayList<Series> viewAllSeries(String studyId) throws Exception
	{
		return DicomVRController.viewSeries(studyId);
	}
	
	public  LinkedHashMap<String, String> details(String stdyId, String srsId, String imgNumber) throws Exception
	{
		return ImageDAO.details(stdyId, srsId, imgNumber);
	}
	
	public void insertImage(model.Image i) throws Exception
	{
		ImageDAO.insert(i);
	}
	
	public void insertPatient(PatientStudy pStudy) throws Exception {
		PatientStudyDAO.insert(pStudy);
	}
	
	public void insertSeries(Series s) throws Exception
	{
		SeriesDAO.insert(s);
	}

}
