package test;


import java.io.File;

import org.junit.jupiter.api.Test;

class TestParseDCMFile {

	@Test
	void test() throws Exception {
		JunitTestDicomVR testDicomVR = new JunitTestDicomVR();
		testDicomVR.parseDCMFile(new File("C:\\Users\\1026837\\Desktop\\dicom 2\\0003.DCM"));		
			
	}

}
