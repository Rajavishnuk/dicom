package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import model.PatientStudy;

class TestViewAllPatient {

	@Test
	void test() throws Exception {
		JunitTestDicomVR patient = new JunitTestDicomVR();
		ArrayList<PatientStudy> patientStudies = patient.viewAllPatient();
		assertEquals("2.16.840.1.114488.0.4.123489834087.1330071425.0", patientStudies.get(0).getStudyId());
	}

}
