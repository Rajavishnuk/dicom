package logger;

public abstract class Test {
	protected int a = 10;
		
	
}
