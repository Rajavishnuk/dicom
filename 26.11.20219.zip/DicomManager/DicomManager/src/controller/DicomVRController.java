package controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.dcm4che3.data.Attributes;
import org.postgresql.util.PSQLException;

import dao.ImageDAO;
import dao.PatientStudyDAO;
import dao.SeriesDAO;
import model.DCMParser;
import model.Image;
import model.PatientStudy;
import model.Series;

public class DicomVRController {

	static DCMParser dcmParser;
	private PatientStudy pStudy;
	private Series series;
	private Image image;
	
	private static Logger logger = Logger.getLogger(DicomVRController.class.getName());
	
	public static Logger getLogger() throws SecurityException, IOException
	{
		//logger.addHandler(LoggerFormat.getFileHandler());
		logger.setLevel(Level.FINE);
		return logger;
	}
	public DicomVRController(PatientStudy pStudy, Series series, Image image) {
		this.pStudy = pStudy;
		this.series = series;
		this.image = image;
	}

	public DicomVRController(DCMParser dcmParser) throws SecurityException, IOException  {		
		DicomVRController.dcmParser = dcmParser;
		//logger.addHandler(LoggerFormat.getFileHandler());
		logger.setLevel(Level.FINE);
		logger.info("Controller initiated...!");		
	}

	public static void parseDCMFile(File f) throws Exception {
		dcmParser.dcmFileParser(f);		
	}

	public static ArrayList<String> getPatientStudyTags()  {
		ArrayList<String> patientStudy = dcmParser.getPatientStudyList();
		return patientStudy;		
	}

	public static ArrayList<String> getSeriesTags()  {
		ArrayList<String> series = dcmParser.getSeriesList();

		return series;
	}

	public static ArrayList<String> getImageTags() {
		ArrayList<String> image = dcmParser.getImageList();

		return image;
	}

	public void insertPatientStudy() throws PSQLException, Exception {
		try {
			PatientStudyDAO.insert(pStudy);
			logger.info("Patient study : inserted successfully");
		} catch (PSQLException e) {
			throw e;
		}
	}

	public void insertSeries() throws PSQLException, Exception {
		try {

			SeriesDAO.insert(series);
			logger.info("Series : inserted successfully");
		} catch (PSQLException e) {
			throw e;
		} 

	}

	public void insertImage() throws PSQLException, Exception {
		try {
			ImageDAO.insert(image);
			logger.info("Image : inserted successfully");
		} catch (PSQLException e) {
			throw e;
		} 

	}	

	public static ArrayList<Series> viewSeries(String studyId) throws Exception {
		ArrayList<Series> list = SeriesDAO.viewSeriesByStudy(studyId);
		logger.info("Series : retrieval");
		return list;
	}
	public static ArrayList<PatientStudy> viewAllPatientStudy() throws Exception {
		ArrayList<PatientStudy> list=PatientStudyDAO.viewAllPatientStudy();
		logger.info("Patient study : retrieval");
		return list;
	}
	public static ArrayList<Image> viewImage(String studyId, String seriesId) throws Exception {
		ArrayList<Image> list = ImageDAO.viewImageBySeries(studyId, seriesId);
		logger.info("Image : retrieval");
		return list;
	}
	public static Attributes getTagSet() {
	
		return DCMParser.getTags();
	}
	
	public  Image getImage()
	{
		return image;
	}
	public PatientStudy getPatient() {
		
		return pStudy;
	}
	public Series getSeries() {		
		return series;
	}
	
	

}
