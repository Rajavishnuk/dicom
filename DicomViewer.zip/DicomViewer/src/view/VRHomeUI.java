package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VRHomeUI extends JFrame {

	private JPanel contentPane;
	static VRHomeUI frame ;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				
					frame = new VRHomeUI();
					frame.setVisible(true);
				
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VRHomeUI() {
		setTitle("Dicom VR");
		
		setBounds(100, 100, 451, 176);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnViewer = new JButton("Viewer");
		btnViewer.setBounds(111, 79, 82, 23);
		btnViewer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
					Viewer.ViewerUI();
				
			}
		});
		
		JButton btnReader = new JButton("Reader");
		btnReader.setBounds(279, 79, 91, 23);
		btnReader.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//ReaderHome.ReaderUI();
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnViewer);
		contentPane.add(btnReader);
	}
}
